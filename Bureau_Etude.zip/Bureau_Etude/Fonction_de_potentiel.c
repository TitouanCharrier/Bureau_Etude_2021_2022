#include "src/Fonction_de_potentiel.h"

int n = 1; //Cette valeur définie le niveau d'énergie

double L = 1;

double V(double x) { //Vous pouvez modifier la fonction V(x) qui correspond 
  if (x<=0.5) {       //au potentiel présent dans le puit.
    return 0;
  } else {
    return 0;
  }
}
