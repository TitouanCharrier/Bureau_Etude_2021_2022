#ifndef F_POTENTIEL
#define F_POTENTIEL

double V(double x);

#endif